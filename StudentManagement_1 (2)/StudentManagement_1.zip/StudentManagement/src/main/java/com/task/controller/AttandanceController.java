package com.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.entity.Attandance;
import com.task.exception.AttandanceNotFoundException;

import com.task.service.AttandanceService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/atten")
public class AttandanceController {
	
	@Autowired
	private AttandanceService attendanceService;
	
	
	@PostMapping
	public Attandance saveStudent(@Valid @RequestBody  Attandance   attandance )
	{
		return attendanceService.insertAttendance(attandance);
    }
	
	@GetMapping("/all")
	public List< Attandance > allAttandance ()
	{
		return attendanceService.getAllAttandance();
    }
	
	@GetMapping("/{id}")
	public Attandance getAttandance(@PathVariable int id) throws  AttandanceNotFoundException
	{
		return attendanceService.getId(id);
    }

	@PutMapping("/{id}")
	public Attandance updatePro(@PathVariable int id,@RequestBody Attandance attandance)
	{
		return attendanceService.updateAttandance(id, attandance);
		
	}
	
	@DeleteMapping("/{id}")
	public String deleteId(@PathVariable int id)
	{
		attendanceService.deleteAttandance(id);
		return "Your data is deleted";
	}
}
