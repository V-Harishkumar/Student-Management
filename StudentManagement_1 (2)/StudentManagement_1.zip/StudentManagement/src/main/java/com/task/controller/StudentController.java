package com.task.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.entity.Student;
import com.task.entity.StudentExam;
import com.task.exception.StudentNotFoundException;

import com.task.service.StudentService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/student")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	
	@PostMapping
	public Student saveStudent(@Valid @RequestBody Student student)
	{
		return studentService.insertStudent(student);
    }
	
	@GetMapping("/all")
	public List<Student> allStudent()
	{
		return studentService.getAllStudent();
    }
	
	@GetMapping("/{id}")
	public Student getStudent(@PathVariable int id) throws StudentNotFoundException
	{
		return studentService.getId(id);
    }

	@PutMapping("/{id}")
	public Student updatePro(@PathVariable int id,@RequestBody Student student)
	{
		return studentService.updateStudent(id, student);
		
	}
	
	@DeleteMapping("/{id}")
	public String deleteId(@PathVariable int id)
	{
		studentService.deleteStudent(id);
		return "Your data is deleted";
    }
	
	@GetMapping("/choose/{field}")
	public List<Student> getProductWithSorting(@PathVariable String field){
			return studentService.sorting(field);
	}
	
	@DeleteMapping("/softdelete/{id}")
	public String softdelete(@PathVariable int id)
	{
			studentService.softDelete(id);
			return "your data is deleted";
	}
	
	@PostMapping("/restore/{id}")
	public String restoredelete(@PathVariable int id) 
	{
			studentService.restoreDelete(id);
			return "your data is restore";
	}
	
	@GetMapping("/softdelete")
	public List<Student> getallStudent()
	{
		return studentService.softgetAllStudent();
    }
}
