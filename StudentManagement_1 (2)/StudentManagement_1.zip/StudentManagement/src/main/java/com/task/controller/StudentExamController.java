package com.task.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.task.entity.StudentExam;
import com.task.exception.StudentExamNotFoundException;
import com.task.service.StudentExamService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/exam")
public class StudentExamController {
	
	@Autowired
	private StudentExamService studentexamservice;
	
	@PostMapping
	public StudentExam saveStudentExam(@Valid @RequestBody StudentExam studentExam)
	{
		return studentexamservice.insertStudentExam(studentExam);
    }
	
	@GetMapping("/all")
	public List<StudentExam> allStudent()
	{
		return studentexamservice.getAllStudentExam();
    }
	
	@GetMapping("/{id}")
	public StudentExam getStudentExam(@PathVariable int id) throws StudentExamNotFoundException
	{
		return studentexamservice.getId(id);
    }

	@PutMapping("/{id}")
	public StudentExam updatePro(@PathVariable int id,@RequestBody StudentExam studentExam)
	{
		return studentexamservice.updateStudentExam(id, studentExam);
		
	}
	
	@DeleteMapping("/soft-delete/{id}")
	public String softDelte(@PathVariable int id)
	{
		 studentexamservice.softDeleteExam(id);
		 return "your data is deleted";
	}
	
	@GetMapping("/softdelete")
	public List<StudentExam> allStudentExam()
	{
		return studentexamservice.softgetAllStudentExam();
    }
	
	@PostMapping("/restore/{id}")
	public String restoredelete(@PathVariable int id) 
	{
			studentexamservice.restoreDelete(id);
			return "your data is restore";
	}
}
