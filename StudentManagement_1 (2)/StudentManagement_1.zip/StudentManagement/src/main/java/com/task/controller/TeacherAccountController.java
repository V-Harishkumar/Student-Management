package com.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.task.entity.TeacherAccount;
import com.task.exception.TeacherAccountNotFoundException;
import com.task.exception.StudentNotFoundException;
import com.task.pojo.Tokens;
import com.task.service.TeacherAccountService;
import com.task.serviceIml.JwtsService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/account")
public class TeacherAccountController {
	
	@Autowired
	private TeacherAccountService studentAccountService ;
	
	@Autowired
	private JwtsService jwtservice;
	
	@PostMapping
	public String saveStudentAccount(@Valid @RequestBody TeacherAccount studentaccount)
	{
		studentAccountService.insertStudentAccount(studentaccount);
		return "Your details store sucessfuly";
    }
	
	@GetMapping("/all")
	public List<TeacherAccount> allStudentAccount()
	{
		return studentAccountService.getAllStudentAccount();
	}
	
	@GetMapping("/{id}")
	public TeacherAccount getStudentAccount(@PathVariable int id) throws StudentNotFoundException, TeacherAccountNotFoundException
	{
		return studentAccountService.getId(id);
    }

	@PutMapping("/{id}")
	public TeacherAccount updatePro(@PathVariable int id,@RequestBody TeacherAccount studentaccount)
	{
		return studentAccountService.updateStudentAccount(id, studentaccount);
		
	}
	
	@PostMapping("/token")
	public String generate(@RequestBody Tokens token)
	{
		return jwtservice.TokenGenerate(token.getName(), token.getPassword());
	}
	
}
