package com.task.entity;

import java.util.List;
import java.util.Set;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "student")
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Size(min=5,max=20,message="please write 5 to 20 characters")
	private String firstname;
	@Size(min=5,max=20,message="please write 5 to 20 characters")
	private String lastname;	
	private long parentsnumber;
	@Size(min=5,max=50,message="please write 5 to 50 characters")
	private String adress;
	private String section;
	private int classes;
	
	private boolean deleted;
	
	@OneToMany(mappedBy="student")
	private List<StudentExam> studentexam;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="attandance_id",referencedColumnName="id")
	private Attandance attandance;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="teacheraccount_id",referencedColumnName="id")
	private TeacherAccount teacheraccount;
}
