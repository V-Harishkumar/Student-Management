package com.task.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "teacheraccount")
public class TeacherAccount {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Size(min=5,max=20,message="please write 5 to 20 characters")
	private String name;
	@Size(min=5,max=20,message="please create strong password and use special characters also")
	private String password;
	@Email(message="create email properly")
	private String email;
	private long accountnumber;
	
//	@OneToOne(mappedBy="teacheraccount")
//	private TeacherAccount teacheraccount;
	
}
