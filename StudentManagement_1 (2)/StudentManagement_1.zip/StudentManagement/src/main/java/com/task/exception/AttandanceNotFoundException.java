package com.task.exception;

public class AttandanceNotFoundException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public AttandanceNotFoundException(String message)
	{
		super(message);
	}
}
