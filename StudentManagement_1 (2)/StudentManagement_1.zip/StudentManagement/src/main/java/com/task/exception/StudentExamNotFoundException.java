package com.task.exception;

public class StudentExamNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public  StudentExamNotFoundException(String message)
	{
		super(message);
	}
}
