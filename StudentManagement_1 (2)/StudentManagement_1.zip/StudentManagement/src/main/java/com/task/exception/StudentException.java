package com.task.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@RestController
public class StudentException {
	
	@ExceptionHandler(StudentNotFoundException.class)
	public Map<String,String> handleStudentException(StudentNotFoundException ex)
	{
		Map<String,String> errorMap=new HashMap<>();
		errorMap.put("error message is", ex.getMessage());
		return errorMap;
	}
	
	@ExceptionHandler(AttandanceNotFoundException.class)
	public Map<String,String> handleAttandanceException(AttandanceNotFoundException ex)
	{
		Map<String,String> errorMap=new HashMap<>();
		errorMap.put("error message is", ex.getMessage());
		return errorMap;
	}
	
	@ExceptionHandler(StudentExamNotFoundException.class)
	public Map<String,String> handleStudentExamException(StudentExamNotFoundException ex)
	{
		Map<String,String> errorMap=new HashMap<>();
		errorMap.put("error message is", ex.getMessage());
		return errorMap;
	}
	
	@ExceptionHandler(TeacherAccountNotFoundException.class)
	public Map<String,String> handleStudentAccountException(TeacherAccountNotFoundException ex)
	{
		Map<String,String> errorMap=new HashMap<>();
		errorMap.put("error message is", ex.getMessage());
		return errorMap;
	}
}
