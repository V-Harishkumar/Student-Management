package com.task.exception;

public class TeacherAccountNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public TeacherAccountNotFoundException(String message)
	{
		super(message);
	}
}
