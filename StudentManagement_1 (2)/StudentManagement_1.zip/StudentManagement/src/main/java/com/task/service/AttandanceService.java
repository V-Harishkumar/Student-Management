package com.task.service;

import java.util.List;

import com.task.entity.Attandance;
import com.task.exception.AttandanceNotFoundException;

public interface AttandanceService {
	
	Attandance insertAttendance(Attandance attendance);
	List<Attandance> getAllAttandance();
	void deleteAttandance(int id);
	Attandance getId(int id)throws AttandanceNotFoundException;
	Attandance updateAttandance(int id, Attandance attandance);
}
