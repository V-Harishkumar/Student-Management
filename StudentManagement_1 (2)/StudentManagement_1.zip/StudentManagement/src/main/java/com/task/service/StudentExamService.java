package com.task.service;

import java.util.List;
import com.task.entity.StudentExam;
import com.task.exception.StudentExamNotFoundException;

public interface StudentExamService {
	
	StudentExam insertStudentExam(StudentExam studentexam);
	List<StudentExam> getAllStudentExam();
	void deleteStudent(int id);
	StudentExam getId(int id)throws StudentExamNotFoundException;
	StudentExam updateStudentExam(int id, StudentExam studentexam);
	
	 void softDeleteExam(int id);
	 public List<StudentExam> softgetAllStudentExam(); 
	 void restoreDelete(int id); 
}
