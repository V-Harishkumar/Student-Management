package com.task.service;

import java.util.List;

import com.task.entity.Student;
import com.task.exception.StudentNotFoundException;


public interface StudentService {
	
	Student insertStudent(Student student);
	List<Student> getAllStudent();
	void deleteStudent(int id);
	Student getId(int id)throws StudentNotFoundException;
	Student updateStudent(int id, Student student);
	
	List<Student> sorting(String field);
	void softDelete(int id); 
	void restoreDelete(int id); 
	public List<Student> softgetAllStudent(); 
	
}
