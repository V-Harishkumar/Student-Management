package com.task.service;

import java.util.List;

import com.task.entity.TeacherAccount;
import com.task.exception.TeacherAccountNotFoundException;


public interface TeacherAccountService {
	
	String insertStudentAccount(TeacherAccount teacheraccount);
	List<TeacherAccount> getAllStudentAccount();
	void deleteStudentAccount(int id);
	TeacherAccount getId(int id)throws TeacherAccountNotFoundException;
	TeacherAccount updateStudentAccount(int id, TeacherAccount teacheraccount);
}
