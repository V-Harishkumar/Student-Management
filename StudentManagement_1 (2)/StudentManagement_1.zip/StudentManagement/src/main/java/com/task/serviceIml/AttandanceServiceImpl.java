package com.task.serviceIml;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.entity.Attandance;
import com.task.exception.AttandanceNotFoundException;
import com.task.repository.AttandanceRepository;
import com.task.service.AttandanceService;

@Service
public class AttandanceServiceImpl implements AttandanceService{
	
	@Autowired
	private AttandanceRepository attenRepo;
	
	
	@Override
	public Attandance insertAttendance(Attandance attendance) {
		
		return attenRepo.save(attendance);
	}

	@Override
	public List<Attandance> getAllAttandance() {
		
		return attenRepo.findAll();
	}

	@Override
	public void deleteAttandance(int id) {
		attenRepo.deleteById(id);
		
	}

	@Override
	public Attandance getId(int id) throws AttandanceNotFoundException {
		
		return attenRepo.findById(id).orElseThrow(()->new AttandanceNotFoundException("ATTENDANCE NOT PRESANT IN ID = "+ id));
	}


	@Override
	public Attandance updateAttandance(int id, Attandance attandance) {
		
		Attandance attandance1=attenRepo.findById(id).get();
		attandance1.setPresant(attandance.getPresant());
		attandance1.setLeave(attandance.getLeave());
		return attenRepo.save(attandance1);
	}

}
