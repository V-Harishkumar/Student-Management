package com.task.serviceIml;

import java.security.Key;
import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtsService {
	
public String TokenGenerate(String name,String password) {
		
		Map<String,Object> claims=new HashMap<>();
		return TokenDetails(claims,name,password);
}
	
	private String TokenDetails(Map<String, Object> claims, String name,String password) {
		
		return Jwts.builder()
				.setClaims(claims)
				.setSubject(name)
				.setSubject(password)
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis()+1000*60*60))
				.signWith(getSecKey(), SignatureAlgorithm.HS256).compact();
	}

		private  Key getSecKey() {
			
			byte[] keyBytes = Decoders.BASE64URL.decode("5367566B59703373377539792F423F4528482B4D6251655468576D5A71347ASD");
			return Keys.hmacShaKeyFor(keyBytes);
			
		}
}
