package com.task.serviceIml;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.entity.StudentExam;
import com.task.exception.StudentExamNotFoundException;
import com.task.repository.StudentExamRepository;
import com.task.service.StudentExamService;

@Service
public class StudentExamServiceImpl implements StudentExamService{
	
	@Autowired
	private StudentExamRepository studentExamRepo;
	
	@Override
	public StudentExam insertStudentExam(StudentExam studentexam) {
		
		return studentExamRepo.save(studentexam);
	}

	@Override
	public List<StudentExam> getAllStudentExam() {
		
		return studentExamRepo.findAll();
	}

	@Override
	public void deleteStudent(int id) {
		studentExamRepo.deleteById(id);
		
	}

	@Override
	public StudentExam getId(int id) throws StudentExamNotFoundException {
	
		return studentExamRepo.findById(id).orElseThrow(()-> new StudentExamNotFoundException("STUDENTEXAM NOT PRESANT IN THE ID = "+ id));
	}

	@Override
	public StudentExam updateStudentExam(int id, StudentExam studentexam) {
		
		StudentExam sx= studentExamRepo.findById(id).get();
		sx.setExamname(studentexam.getExamname());
		sx.setTotalmark(studentexam.getTotalmark());
		
		return studentExamRepo.save(sx);
	}

	@Override
	public void softDeleteExam(int id) {
		StudentExam studentexam=studentExamRepo.findById(id).orElseThrow();
		studentexam.setDeleted(true);
		studentExamRepo.save(studentexam);
		
		
	}

	@Override
	public List<StudentExam> softgetAllStudentExam() {
		
	   return studentExamRepo.findByDeletedFalse();
	}

	@Override
	public void restoreDelete(int id) {
		
		StudentExam studentexam=studentExamRepo.findById(id).orElseThrow();
		studentexam.setDeleted(false);
		studentExamRepo.save(studentexam);
	}
}
