package com.task.serviceIml;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.task.entity.Student;
import com.task.entity.StudentExam;
import com.task.exception.StudentNotFoundException;
import com.task.repository.StudentRepository;
import com.task.service.StudentService;

@Service
public class StudentServiceIml implements StudentService{
	
	@Autowired
	private StudentRepository studentRepository;

//This method is created by POST method	
	@Override
	public Student insertStudent(Student student) {
		
		return studentRepository.save(student);
	}

//This method is created by POST method	
	@Override
	public List<Student> getAllStudent() {
		
		return studentRepository.findAll();
	}

//This method is created by DELETE method	
	@Override
	public void deleteStudent(int id) {
		
		 studentRepository.deleteById(id);
	}

//This method is created by GET method	
	@Override
	public Student getId(int id) throws StudentNotFoundException {
		
		return studentRepository.findById(id).orElseThrow(() -> new StudentNotFoundException("NO STUDENT PRESENT WITH ID = " + id));
	}
//This method is created by PUT method	
	@Override
	public Student updateStudent(int id, Student student) {
		
		Student student1=studentRepository.findById(id).get();
		student1.setLastname(student.getLastname());
		student1.setFirstname(student.getFirstname());
		
		return studentRepository.save(student1);
		
	}

//This method is created by GET method		
	@Override
	public List<Student> sorting(String field) {
		
		return studentRepository.findAll(Sort.by(Sort.Direction.ASC ,field));
	}
	

//Method is created by DELETE method	
	@Override
	public void softDelete(int id) {
			Student student=studentRepository.findById(id).orElse(null);
			if(student!=null)
			{
				student.setDeleted(true);
				studentRepository.save(student);
			}
			
		}

//Method is created by POST method	
		@Override
		public void restoreDelete(int id) {
			
			Student student=studentRepository.findById(id).orElse(null);
			if(student!=null)
			{
				student.setDeleted(false);
				studentRepository.save(student);
			}
		}
		
//Method is created by GET method	
		@Override
		public List<Student> softgetAllStudent() {
			
			return studentRepository.findByDeletedFalse() ;
		}

}
