package com.task.serviceIml;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.task.entity.TeacherAccount;
import com.task.exception.TeacherAccountNotFoundException;
import com.task.repository.TeacherAccountRepository;
import com.task.service.TeacherAccountService;

@Service
public class TeacherAccountServiceImp implements TeacherAccountService{
	
	@Autowired
	private TeacherAccountRepository studentaccountRepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
	@Override
	public String  insertStudentAccount(TeacherAccount studentaccount) {
		
		studentaccount.setPassword(passwordEncoder.encode(studentaccount.getPassword()));
		studentaccountRepo.save(studentaccount);
		return "Your details store sucessfuly";
	}

	@Override
	public List<TeacherAccount> getAllStudentAccount() {
		
		return studentaccountRepo.findAll();
	}

	@Override
	public void deleteStudentAccount(int id) {
		studentaccountRepo.deleteById(id);
		
	}

	@Override
	public TeacherAccount getId(int id) throws TeacherAccountNotFoundException  {
		
		return studentaccountRepo.findById(id).orElseThrow(()->new TeacherAccountNotFoundException("STUDENTACCOUNT NOT PRESANT IN THE ID ="+id) );
	}

	@Override
	public TeacherAccount updateStudentAccount(int id, TeacherAccount studentaccount) {
		
		TeacherAccount studentaccount1=studentaccountRepo.findById(id).get();
		studentaccount1.setName(studentaccount.getName());
		studentaccount1.setPassword(studentaccount.getName());
		studentaccount1.setEmail(studentaccount.getName());
		studentaccount1.setAccountnumber(studentaccount.getAccountnumber());		
		return studentaccountRepo.save(studentaccount1);
	}

}
